package com.ing.billing.beans;
public class Address {
	
	private String city, state;
	private int pinCode;
	


}